
USE fashion_store;

INSERT INTO Role (name, description) VALUES 
('admin', 'Administrator with full access'),
('customer', 'Normal customer');

