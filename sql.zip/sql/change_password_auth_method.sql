ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Diep2105@';
FLUSH PRIVILEGES;