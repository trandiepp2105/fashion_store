CREATE DATABASE IF NOT EXISTS fashion_store;
USE fashion_store;